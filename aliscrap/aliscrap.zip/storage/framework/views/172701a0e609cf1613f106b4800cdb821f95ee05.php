<?php $__env->startSection('content'); ?>
<div class="col-md-8 col-lg-8">
	<div class="card mb-4">
									<div class="card-block">
										<h3 class="card-title">Profile </h3>
										
									
										
										<h6 class="card-subtitle mb-2 text-muted"></h6>
										
										<form class="form-horizontal" action="<?php echo e(route('profile')); ?>" method="POST">
										 <?php echo e(csrf_field()); ?>

											<fieldset>
												<!-- Name input-->
												<div class="form-group">
													<label class="col-12 control-label no-padding" for="name">Name</label>
													
													<div class="col-12 no-padding">
														<input id="name" name="name" type="text" placeholder="Your name" value="<?php echo e($user->name); ?>" class="form-control">
													</div>
												</div>
											
												<!-- Email input-->
												<div class="form-group">
													<label class="col-12 control-label no-padding" for="email">Your E-mail</label>
													
													<div class="col-12 no-padding">
														<input id="email" name="email" type="text" placeholder="Your email" value="<?php echo e($user->email); ?>" class="form-control">
													</div>
												</div>

												
												<!-- Form actions -->
												<div class="form-group">
													<div class="col-6 widget-left no-padding">
														  <a href="<?php echo e(route('logout')); ?>" class="btn btn-warning btn-md float-left"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                           Logout
                                        </a>
														
													</div>
													<div class="col-6 widget-right no-padding">
														<button type="submit" class="btn btn-primary btn-md float-right">Update</button>
													</div>
												</div>
											</fieldset>
										</form>
									</div>
								</div>
							
							
							</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>