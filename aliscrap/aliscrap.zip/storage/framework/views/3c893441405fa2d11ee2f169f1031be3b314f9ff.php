<?php $__env->startSection('content'); ?>
<div class="col-md-12 col-lg-12">
								<div class="jumbotron">
									<h1 class="mb-4">Hi DropShipper</h1>
									
									<p class="lead">
									Aliscrap is a simple solution to import products from aliexpress, at the moment we supporting wooCommerce site only.
									</p>
									
									<p>To start importing please install our chrome extension</p>
									
									<p class="lead"><a class="btn btn-primary btn-lg mt-2" href="https://chrome.google.com/webstore/detail/aliscrap/mdpaflbjhcjbmaojlnpejkhefodmjdbd" role="button" target="_blank">Install</a></p>
								</div>

								
								<div class="card mb-4">
									<div class="card-block">
										<h3 class="card-title">Recent Products</h3>
										
										
										
										<div class="table-responsive">
											<table class="table table-striped">
												<thead>
													<tr>
														<th>Id</th>
														
														<th>Link</th>
														
														<th>Image</th>
														
														<th>Description</th>
														<th>From</th>
														<th>Price</th>
													</tr>
												</thead>
												
												<tbody>
												<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
														<td>#<?php echo e($product->id); ?></td>
														
														<td> <a href="<?php echo e($product->link); ?>">Product link</a></td>
														
														<td> <img src="<?php echo e($product->image); ?>" alt="" height="55" width="55"></td>
														
														<td>
														<textarea rows="3" cols="40"><?php echo e($product->description); ?></textarea>		
														
														</td>
														<td> <a href="<?php echo e($product->site_name); ?>"><?php echo e($product->site_name); ?></a></td>
														<td><?php echo e($product->price); ?> <?php echo e($product->priceCurrency); ?> </td>
													</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													
													
												</tbody>
											</table>
										</div>
									</div>
								</div>
								
							
							
							</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>