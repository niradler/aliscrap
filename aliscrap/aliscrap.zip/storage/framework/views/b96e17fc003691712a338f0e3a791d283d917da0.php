<header class="page-header row justify-center">
	<div class="col-md-6 col-lg-8">
		<h1 class="float-left text-center text-md-left">Dashboard</h1>
	</div>

	<div class="dropdown user-dropdown col-md-6 col-lg-4 text-center text-md-right"><a class="btn btn-stripped dropdown-toggle" href="https://example.com" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
		    aria-expanded="false">
						<img src="images/user.png" alt="profile photo" class="circle float-left profile-photo" width="50" height="auto">
						
						<div class="username mt-1">
							<h4 class="mb-1">
							  <?php if(Auth::user()!==null): ?><?php echo e(Auth::user()->name); ?><?php endif; ?>
							</h4>
							
							<h6 class="text-muted">
							 <?php if(Auth::user()!==null): ?><?php echo e(Auth::user()->email); ?><?php endif; ?>
							</h6>
						</div>
						</a>

		 <?php if(Auth::guest()): ?>
		 <div class="dropdown-menu dropdown-menu-right" style="margin-right: 1.5rem;" aria-labelledby="dropdownMenuLink">
                            <a class="dropdown-item" href="<?php echo e(route('login')); ?>">Login</a>
                           <a  class="dropdown-item" href="<?php echo e(route('register')); ?>">Register</a>
						   <div>
                        <?php else: ?>
						<div class="dropdown-menu dropdown-menu-right" style="margin-right: 1.5rem;" aria-labelledby="dropdownMenuLink">
		<a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><em class="fa fa-user-circle mr-1"></em> View Profile</a>
			<a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><em class="fa fa-power-off mr-1"></em> Logout</a>
			</div>
			   <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                            
                        <?php endif; ?>
	</div>

	<div class="clear"></div>
</header>
  