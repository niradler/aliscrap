<nav class="sidebar col-xs-12 col-sm-4 col-lg-3 col-xl-2 bg-faded sidebar-style-1">
				<h1 class="site-title"><a href="<?php echo e(route('dashboard')); ?>"><em class="fa fa-rocket"></em> <?php echo e(config('app.name', 'Aliscrap')); ?></a></h1>
				
				<a href="#menu-toggle" class="btn btn-default" id="menu-toggle"><em class="fa fa-bars"></em></a>
				
				<ul class="nav nav-pills flex-column sidebar-nav">
					<li class="nav-item">
                    <a class="nav-link <?php echo e((request()->route()->getName() == 'dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>"><em class="fa fa-dashboard"></em> Dashboard 
                    <span class="sr-only">(current)</span></a>
                    </li>
					<li class="nav-item">
                    <a class="nav-link <?php echo e((request()->route()->getName() == 'products') ? 'active' : ''); ?>" href="<?php echo e(route('products')); ?>"><em class="fa fa-calendar-o"></em> Products</a>
                    </li>
                    		<li class="nav-item">
                    <a class="nav-link <?php echo e((request()->route()->getName() == 'exportImport') ? 'active' : ''); ?>" href="<?php echo e(route('exportImport')); ?>"><em class="fa fa-calendar-o"></em> Export / Import</a>
                    </li>
						

				</ul>
				 <?php if(Auth::guest() ): ?>
                     
                        <?php else: ?>
                     
                                        
                        <?php endif; ?>
				
			
                </nav>
			
